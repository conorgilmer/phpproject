<?php /* Smarty version Smarty-3.1.15, created on 2013-12-15 16:06:07
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/front.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2384639752adc55f1e1869-47264670%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '336d98101c3b5c7d00ee33f233e062d60540fb05' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/front.tpl',
      1 => 1387083953,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2384639752adc55f1e1869-47264670',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_52adc55f1e3e95_67800025',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52adc55f1e3e95_67800025')) {function content_52adc55f1e3e95_67800025($_smarty_tpl) {?>
    <div class="container">
      <!-- Example row of columns -->
      <div class="row">
        <div class="col-lg-4">
          <h2>List Properties</h2>
          <p>List Properties by Counties. </p>
          <p><a class="btn btn-default" href="index.php?action=listcounties">Property Listings&raquo;</a></p>
        </div>
        <div class="col-lg-4">
          <h2>List Agents</h2>
          <p>List Real Estate Agents. </p>
          <p><a class="btn btn-default" href="index.php?action=listcontacts">View Agents &raquo;</a></p>
       </div>
              <div class="col-lg-4">
          <h2>List Agents</h2>
          <p>List Real Estate Agents. </p>
          <p><a class="btn btn-default" href="index.php?action=listcontacts">View Agents &raquo;</a></p>
       </div>
          
      </div><?php }} ?>

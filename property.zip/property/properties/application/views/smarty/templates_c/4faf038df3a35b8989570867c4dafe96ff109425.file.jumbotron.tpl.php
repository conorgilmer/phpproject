<?php /* Smarty version Smarty-3.1.15, created on 2013-12-15 16:06:07
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/jumbotron.tpl" */ ?>
<?php /*%%SmartyHeaderCode:123718223152adc55f1dc290-09500505%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4faf038df3a35b8989570867c4dafe96ff109425' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/jumbotron.tpl',
      1 => 1387056311,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '123718223152adc55f1dc290-09500505',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_52adc55f1ddf51_43469811',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52adc55f1ddf51_43469811')) {function content_52adc55f1ddf51_43469811($_smarty_tpl) {?>
    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <h1>Welcome!</h1>
        <p>Welcome to GAFF your property website.</p>
        <p><a class="btn btn-primary btn-lg">Learn more &raquo;</a></p>
      </div>
    </div><?php }} ?>

<?php /* Smarty version Smarty-3.1.15, created on 2013-12-15 17:08:07
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/editproperty.tpl" */ ?>
<?php /*%%SmartyHeaderCode:179716656652add3e7a21c74-99821903%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4cf654195955ef2ce8a8cacf7430f0462d3be880' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/editproperty.tpl',
      1 => 1387123544,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '179716656652add3e7a21c74-99821903',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_52add3e7a60a27_78270535',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52add3e7a60a27_78270535')) {function content_52add3e7a60a27_78270535($_smarty_tpl) {?> <div class="container">
     
<div class='row'>
    <div class='col-md-2'>Edit Property</div>
    <div class='col-md-4'> <?php echo $_smarty_tpl->getSubTemplate ("form_property.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
 </div>
     <div class='col-md-6'> </div>
</div>
     
         </div><!-- /end container -->
<?php }} ?>

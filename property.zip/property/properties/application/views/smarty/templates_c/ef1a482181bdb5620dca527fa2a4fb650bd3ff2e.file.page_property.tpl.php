<?php /* Smarty version Smarty-3.1.15, created on 2013-12-15 16:17:48
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/page_property.tpl" */ ?>
<?php /*%%SmartyHeaderCode:166288018052adc81c4684e5-42912903%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ef1a482181bdb5620dca527fa2a4fb650bd3ff2e' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/page_property.tpl',
      1 => 1387106824,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '166288018052adc81c4684e5-42912903',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_52adc81c4e12a0_34697427',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52adc81c4e12a0_34697427')) {function content_52adc81c4e12a0_34697427($_smarty_tpl) {?> <div class="container">
     
<div class='row'>
    <div class='col-md-2'>I am page one</div>
    <div class='col-md-4'> <?php echo $_smarty_tpl->getSubTemplate ("form_property.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
 </div>
     <div class='col-md-6'> </div>
</div>
     
         </div><!-- /end container -->
<?php }} ?>

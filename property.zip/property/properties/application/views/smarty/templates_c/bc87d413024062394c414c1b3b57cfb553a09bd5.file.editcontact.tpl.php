<?php /* Smarty version Smarty-3.1.15, created on 2013-12-17 16:03:28
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/editcontact.tpl" */ ?>
<?php /*%%SmartyHeaderCode:188315923652b067c05c2b53-39285229%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bc87d413024062394c414c1b3b57cfb553a09bd5' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/editcontact.tpl',
      1 => 1387117465,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '188315923652b067c05c2b53-39285229',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_52b067c073cc98_99302940',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52b067c073cc98_99302940')) {function content_52b067c073cc98_99302940($_smarty_tpl) {?> <div class="container">
     
<div class='row'>
    <div class='col-md-2'>Edit Agent</div>
    <div class='col-md-4'> <?php echo $_smarty_tpl->getSubTemplate ("form_contact.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
 </div>
     <div class='col-md-6'> </div>
</div>
     
         </div><!-- /end container -->
<?php }} ?>

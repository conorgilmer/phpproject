<?php /* Smarty version Smarty-3.1.15, created on 2013-12-15 17:52:10
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/editphoto.tpl" */ ?>
<?php /*%%SmartyHeaderCode:136940527452adde3a4c89f3-33911700%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b1e46241d1e32c5d44bcde9b2d3f51df4a148e3' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/editphoto.tpl',
      1 => 1387126083,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '136940527452adde3a4c89f3-33911700',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_52adde3a50a961_95494177',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52adde3a50a961_95494177')) {function content_52adde3a50a961_95494177($_smarty_tpl) {?> <div class="container">
     
<div class='row'>
    <div class='col-md-2'>Edit Photo</div>
    <div class='col-md-4'> <?php echo $_smarty_tpl->getSubTemplate ("form_photo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
 </div>
     <div class='col-md-6'> </div>
</div>
     
         </div><!-- /end container -->
<?php }} ?>

<?php /* Smarty version Smarty-3.1.15, created on 2013-12-15 16:16:44
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/page_1.tpl" */ ?>
<?php /*%%SmartyHeaderCode:64294086152adc7dc708fe5-01750298%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c57ea02097cedceea37615ebcbf133ac2ceb9675' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/page_1.tpl',
      1 => 1381955064,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '64294086152adc7dc708fe5-01750298',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_52adc7dc77ef33_02316733',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52adc7dc77ef33_02316733')) {function content_52adc7dc77ef33_02316733($_smarty_tpl) {?> <div class="container">
     
<div class='row'>
    <div class='col-md-2'>I am page one</div>
    <div class='col-md-4'> <?php echo $_smarty_tpl->getSubTemplate ("form_movie.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
 </div>
     <div class='col-md-6'> </div>
</div>
     
         </div><!-- /end container -->
<?php }} ?>

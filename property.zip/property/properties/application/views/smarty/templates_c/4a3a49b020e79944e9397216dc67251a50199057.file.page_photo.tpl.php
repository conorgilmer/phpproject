<?php /* Smarty version Smarty-3.1.15, created on 2013-12-15 17:42:21
         compiled from "/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/page_photo.tpl" */ ?>
<?php /*%%SmartyHeaderCode:130603258352adda4eb4e371-08370925%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4a3a49b020e79944e9397216dc67251a50199057' => 
    array (
      0 => '/Applications/XAMPP/xamppfiles/htdocs/phpproject/property/properties/application/views/smarty/templates/page_photo.tpl',
      1 => 1387125385,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '130603258352adda4eb4e371-08370925',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_52adda4ebdb1f7_25338544',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52adda4ebdb1f7_25338544')) {function content_52adda4ebdb1f7_25338544($_smarty_tpl) {?> <div class="container">
     
<div class='row'>
    <div class='col-md-2'>Photo Details</div>
    <div class='col-md-4'> <?php echo $_smarty_tpl->getSubTemplate ("form_photo.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
 </div>
     <div class='col-md-6'> </div>
</div>
     
         </div><!-- /end container -->
<?php }} ?>

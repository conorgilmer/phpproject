
      <div class="footer">
        <p>&copy; Conor Gilmer 2013<br>
	<em><a href="mailto:conor.gilmer@gmail.com">conor.gilmer@gmail.com</a></em></p>
      </div>
    </div>

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>

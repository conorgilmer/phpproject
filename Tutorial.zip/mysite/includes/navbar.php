      <div class="header">
        <ul class="nav nav-pills pull-right">
          <li class="active"><a href="index.php">Home</a></li>
          <li class="active"><a href="hobbies.php">Hobbies</a></li>
          <li class="active"><a href="webelevate.php">Webelevate</a></li>
          <li class="active"><a href="contact.php">Contact</a></li>
        </ul>
        <h3 class="text-muted">Conor Gilmer </h3>
      </div>


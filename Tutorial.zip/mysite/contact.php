      
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>


<div class="jumbotron">
        <h2>Contact</h2>
        <p class="lead">email:<a href="mailto:conor.gilmer@gmail.com">conor.gilmer@gmail.com</a></p>
        <p class="lead">skype: conor.gilmer </p>
        <p class="lead">twitter: <a target="_blank" href="http://www.twitter.com/conorgilmer">twitter.com/conorgilmer</a> </p>
      </div>
<?php include 'includes/footer.php'; ?>

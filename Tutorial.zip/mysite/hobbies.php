      
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>


<div class="jumbotron">
        <h2>Hobbies</h2>
        <p class="lead">I enjoy a number of pastimes and hobbies such as..
<ul>
<li align="left"> Chess - played since i was a child.</li>
<li align="left"> Skiing - Wallet Emptying  </li>
<li align="left"> Guitar Playing - and annoying the neighbours </li>
<li align="left"> Amateur Radio - Call Sign ei5gabs </li>
</ul></p>
      </div>
<?php include 'includes/footer.php'; ?>

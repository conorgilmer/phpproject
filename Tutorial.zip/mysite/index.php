      
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>


<div class="jumbotron">
        <h2>About Me</h2>
        <p class="lead">This is a small website to show basic templating.</p>
        <p class="lead">It uses a php and bootstrap, with a header, navigation and footer as common elements which are imported into each page..</p>
      </div>
<?php include 'includes/footer.php'; ?>

     
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="jumbotron">
<h2>Webelevate 2.1</h2>
<p class="lead"> I am currently participating in the Webelavate 2.1 course at the Digital Skills Academy</p>


<ul>
<li align="left"> Creative Thinking.</li>
<li align="left"> User Centered Design.</li>
<li align="left"> Digital Media History.</li>
<li align="left"> Fundamentals of Programming  </li>
<li align="left"> Mobile Development  </li>
<li align="left"> Internet Development  </li>
<li align="left"> Industry Project  </li>
</ul></p>




  </div>
<?php include 'includes/footer.php'; ?>

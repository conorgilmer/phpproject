      
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<!-- Webapge content goes here -->
<div class="jumbotron">
        <h2>Heading</h2>
        <p class="lead">Enter any text you want in here.</p>
      </div>
<!-- end of individual webpage content-->
<?php include 'includes/footer.php'; ?>
